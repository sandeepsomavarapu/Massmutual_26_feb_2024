
import './App.css';
import Car from './Car';
import Employee from './employee';
import Student from './student';

function App() {
  return (
    <div className="App">
      <h1>am from root APP component</h1>
      <Employee></Employee>
      <Student></Student>    
      <Car></Car>
      </div>
  );
}

export default App;
