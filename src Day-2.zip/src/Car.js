
import React from 'react';
class Car extends React.Component
{
    constructor()
    {
        super();
        this.state={value:true};
    }
    render(){
        const data=this.state.value?(
            <div>
                <p>class components are statefull component</p>
            </div>
        ):String;
        return(
            <div>
                <h1>Am from Car Component : </h1>
                {data}
            </div>
        );
    }
}
export default Car;
