function Employee(){
    return <h1>am from Employee component</h1>
}
export default Employee;