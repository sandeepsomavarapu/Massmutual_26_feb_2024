import React from 'react';
class Student extends React.Component
{
    render()
    {
        return(<div>
            <p>am from student</p>
        </div>)


    }

} 



export default Student;