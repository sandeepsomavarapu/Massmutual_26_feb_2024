import React from "react";
import {  Link } from "react-router-dom";
export default class SignUp extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            emailId: '',
            password: '',
            contact:0,

        }
    }
    changeEmailHandler = (event) => {
        this.setState({ emailId: event.target.value });
    }
    changePasswordHandler = (event) => {
        this.setState({ password: event.target.value });
    }
    changeContactHandler = (event) => {
        this.setState({ contact: event.target.value });
    }
    Register= (e) => {
        e.preventDefault();
        let user = {userID: this.state.emailId, password: this.state.password,contact:this.state.contact};
        alert(user);
        alert("signup done....")
      
    }
    render() {
        return (
            <div className="container">
            <form>
                <h3>Register</h3>
                <div className="form-group">
                    <label>Email</label>
                    <input type="email" value={this.state.emailId} onChange={this.changeEmailHandler}className="form-control" placeholder="Enter email" />
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" value={this.state.password} onChange={this.changePasswordHandler} className="form-control" placeholder="Enter password" />
                </div>

                <div className="form-group">
                    <label>Conatct</label>
                    <input type="text"  value={this.state.contact} onChange={this.changeContactHandler}className="form-control" placeholder="Enter Contact" />
                </div>
                <button type="submit"onClick={this.Register} className="btn btn-dark btn-lg btn-block">Register</button>
                <p className="forgot-password text-right">
                    Already registered  <Link className="nav-link " to={"/sign-in"}>Sign in</Link>
                </p>
            </form>
            </div>
        );
    }
}