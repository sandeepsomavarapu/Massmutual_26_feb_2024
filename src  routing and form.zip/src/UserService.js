
class UserService {
  
     validate=(user)=> {
        if(user.userID==="sandeep" && user.password==="sandeep@123")
        {
        return true;
        }
        else
        {
            return false;
        }
    }
}
export default UserService