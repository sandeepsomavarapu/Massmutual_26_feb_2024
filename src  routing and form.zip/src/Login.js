import React, { Component } from "react";


export default class Login extends Component {

    constructor(props) {
        super(props)
        this.state = {
            emailId: '',
            password: '',
        }
    }
    changeEmailHandler = (event) => {
        this.setState({ emailId: event.target.value });
    }
    changePasswordHandler = (event) => {
        this.setState({ password: event.target.value });
    }
    loginUser= (e) => {
        e.preventDefault();
        let user = {userID: this.state.emailId, password: this.state.password};
        alert(user.userID+" "+user.password)
        if(user.userID==="sandeep" && user.password==="sandeep@123")
        {
        alert("LOGIN SUCCESS")
        }
        else
        {
            alert("login failure")
        }
      
      
    }
    render() {
        return (
            <div className="container">
                <form>

                    <h3>Log in</h3>

                    <div className="form-group">
                        <label>Email</label>
                        <input type="email" value={this.state.emailId} onChange={this.changeEmailHandler} className="form-control" placeholder="Enter email" />
                    </div>

                    <div className="form-group">
                        <label>Password</label>
                        <input type="password" value={this.state.password} onChange={this.changePasswordHandler} className="form-control" placeholder="Enter password" />
                    </div>

                    <div className="form-group">
                        <div className="custom-control custom-checkbox">
                            <input type="checkbox" className="custom-control-input" id="customCheck1" />
                            <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                        </div>
                    </div>

                    <button type="submit" onClick={this.loginUser} className="btn btn-dark btn-lg btn-block">Sign in</button>
                    <p className="forgot-password text-right">
                        Forgot <a href="#">password?</a>
                    </p>
                </form>
            </div>
        );
    }
}