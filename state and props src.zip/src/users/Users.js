import React, { Component } from 'react';
import User from './User';
class Users extends Component {
  // Setting Initial State
  state = {
    users: [
      {name:"naresh", age:20},
      {name:"suresh", age:30},
      {name:"ramesh", age:40},
      {name:"rejesh", age:30},
      {name:"sravan", age:50}
    ],
    title:"Users List"
  }  // Handle to modify state
  makeMeYounger = () => {
    const newState = this.state.users.map((a)=>{
      const tempUser = a;
      tempUser.age -=10;
      return tempUser;
    });
    this.setState({
      newState
    });
  }
  render(){
    return (<div>
      <button onClick={this.makeMeYounger}>Make Us 10 Years Younger</button>
      <br/>
      <h1>{this.state.title}</h1>
      {
        this.state.users.map((a)=>{
          return <User age={a.age} x={this.state}>{a.name}</User>
        })
      }
      </div>)
  }
}

export default Users;
