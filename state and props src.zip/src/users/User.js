import React from 'react';

const User = (props) => {
  //let value=props.age;
 // props.age=props.age+10;
 // value=value+10;
  return (<div>Name: {props.children} | Age: {props.age}| {props.x.users[0].name}</div>)
}

export default User;


